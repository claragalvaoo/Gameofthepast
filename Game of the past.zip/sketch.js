//Variáveis de Cenas
let MENU=1, PRE_JOGO=2, INFORMATIONS=3, CREDITS=4, PLAY=5;
var menuy1 = 130, menuy2 = 180, menuy3 = 232;
var x = 188, l = 240, a = 55;
var bVoltar;

//Variáveis do menu
var cena = 1, img1, img2, img3, img4, img5, img6, img7, img8;

//Variáveis do GamePlay - //30 palavras
//palavras erradas
var palavrasE = [ 'choose', 'came' , 'does', 'drunk', 'drive', 'eated', 'felled', 'flew', 'forgoted', 'rozed', 'getted', 'gaved', 'wont', 'griw', 'hidded', 'know', 'losted', 'readed', 'ranged', 'seed', 'shooked', 'spoked', 'swamed','ware','wonned','gon', 'playd', 'sending', 'wins','laid', 'runned']; 

// palavras corretas
var palavrasC = ['was', 'bore', 'became', 'began', 'broke', 'brought', 'built', 'chose', 'come', 'done', 'drank', 'drove', 'ate', 'fed', 'felt', 'found', 'got', 'gave', 'went', 'had', 'heard', 'hid', 'kept', 'knew', 'led', 'learn', 'lost', 'made', 'meant', 'met', 'paid', 'put', 'read', 'ran'];
var palavras = palavrasE.concat(palavrasC);

var quedas = [];
var speed1 = 1.8, speed2 = 2.3, speed3 = 3.3;
var palavrasItem = [];
var player;
var speedPX = 0;
var isLimiteR = false;
var isLimiteL = false;
var pontos = 0;
var vidas = 5;
var painel;
var isGameOver = false;

function setup() {
  createCanvas(600, 400);
  img1 = loadImage('menujg.png');
  img2 =loadImage ('prejogo.png');
  img3 =loadImage ('tela3info.png');
  img4 =loadImage ('naire.jpeg');
  img5 =loadImage ('clara.png');
  img6 = loadImage ('telajogo01.png');
  img7 = loadImage ('tela4credits.png');
  img8 = loadImage ('gameover.jpg');
  palavras = embaralhar(palavras);
}

function draw() {
  //menu do jogo 
  if (cena==MENU) {
    background(img1, 50);
    
    textSize (35);
    textStyle(BOLD);
    fill(400);
    strokeWeight (2);
    stroke ('black');
    text ('GAME OF THE PAST', 130, 60);
    noFill ();
    
  if (mouseX > x && mouseX < x + l && mouseY > menuy1 && mouseY < menuy1 + a) {
    fill(0)
    noStroke ();
    rect (x-4, menuy1,l, a,15);
    if (mouseIsPressed) {
      cena = 2;   
      criarBotaoVoltar();
    }      
  }
    
  fill(400)
  strokeWeight (1);
  stroke ('black');
  textSize (28);
  text ( 'PLAY NOW!', 226, 170);

  // ~~ menu informações sobre o jogo
  textStyle(BOLD);
  noFill ();
  stroke(10);
  
  if( mouseX > x && mouseX < x + l && mouseY > menuy2 && mouseY < menuy2 + a) {
      fill(0)
      noStroke ();
      rect (x+2, menuy2 ,l, a,15);
      if (mouseIsPressed) {
        cena = 3;
        criarBotaoVoltar();
    }   
  }          
  
  fill(400)
  strokeWeight (1);
  stroke ('black');
  textSize (28);
  text ( 'INFORMATIONS', 206, 220);
  
  // ~~ menu créditos
  textStyle(BOLD); 
  fill (0);
  stroke(10);
   
  if ( mouseX > x && mouseX < x + l && mouseY > menuy3 && mouseY < menuy3 + a) {
    fill(0)
    noStroke ();
    rect (x, menuy3 ,l, a,15);
    if (mouseIsPressed) {
      cena = 4;
      criarBotaoVoltar();
    }
  }       
  
  fill(400)
  strokeWeight (1);
  stroke ('black');
  textSize (28);
  textSize (28);
  text ('CREDITS', 250, 270)
  
  }   
  
  // tela pré jogo ENTER
  if (cena==PRE_JOGO){
    background (img2, 50);
    
    if(keyIsDown(13)){
      cena = 5;
      criarBotaoVoltar();
      gerarPlayer();
      gerarInfo();

      for (i = 0; i < 3; i++) {
        gerarPalavra(i);
      }
    }
  }
  
  if (cena==INFORMATIONS){
    background(img3,50);
    fill('white');
    strokeWeight (1);
    stroke ('black');
    textSize(30);
    textAlign(LEFT);
    text("INFORMATIONS: ",170,60);
    textSize(18);
    textAlign(LEFT);
    text('(EF07LI16) Reconhecer a pronúncia de verbos regulares no passado (-ED). O objetivo do jogo é o aluno reconhecer os verbos no passado em inglês, sejam irregulares ou regulares. Onde o aluno do 7º ano, deverá colidir com as palavras conjugadas no passado de forma CORRETA e desviar de todas as palavras que estão conjugadas no passado de forma ERRADA. A pontuação é recorde, quanto mais palavras acertar maior a sua pontuação!!!               GOOD LUCK!! ', 50,120,490,300);
  }
  
  if (cena==CREDITS){
    background(img7, 10);
    image(img5, 320, 100,190,200)
    image(img4, 80,100,190,200)
    textSize(30);
    noStroke();
    fill('white');
    text("CREDITS: ",220,60);
    textSize(15);
    text("Programadora: Mª Clara G.",320,350);
    text("Educadora: Naire Galvão",90,350)
    
  }
  
  //TELA DO JOGO
  if (cena==PLAY){
    background (img6, 50);

    moverPlayer();
    moverItens();
    checarResetItem();
    checarColisao();
    checarLimites();

    if(vidas>0){
      painel.html("Pontos: " + pontos + "<br>Vidas: " + vidas);
    } else {
      //fim do jogo
      background(img8);
      limparTela();
      painel.html("Pontos: " + pontos);
      isGameOver = true;
    }
  }
}

function limparTela(){
  player.remove();
  palavras = [];
  for (i=0; i<palavrasItem.length; i++){
    palavrasItem[i].remove();
  }
}

function gerarInfo(){
  painel = createDiv("Pontos: " + pontos + "<br>Vidas: " + vidas);
  painel.position(450, 0);
  painel.size(134, 58)
  painel.style("height", "auto")
  painel.style("background", "#55a");
  painel.style("border-bottom-left-radius", "2em");
  painel.style("text-align", "center");
  painel.style("padding", "8px");
  painel.style('font-size', '24px');
  painel.style('color', 'white');
}

function gerarPalavra(i) {
  palavrasItem[i] = createDiv(random(palavras));
  palavrasItem[i].position(random(0, 560), 0);
  palavrasItem[i].style("background", "#55a");
  palavrasItem[i].style("width", "80px");
  palavrasItem[i].style("text-align", "center");
  palavrasItem[i].style('font-size', '24px');
  palavrasItem[i].style('color', 'white');
  palavrasItem[i].style('padding', '4px');
  palavrasItem[i].style("border-style", 'solid');
  palavrasItem[i].style('border-radius', '40px');
  quedas[i] = 0;
}

function gerarPlayer(){
  player = createDiv("");
  player.size(60, 10)
  player.position(260, 380);
  player.style("background", "#55a");
  player.style('font-size', '24px');
  player.style('color', 'white');
  player.style("border-style", 'solid');
  player.style('border-radius', '40px');
}

// movimentação do personagem (Player)
// é chamada quando um butão é pressionado
function keyPressed(){
  if(keyCode == RIGHT_ARROW && !isLimiteR){
    speedPX = 6;
  }
  if(keyCode == LEFT_ARROW && !isLimiteL){
    speedPX = -6;
  }
}

//é chamado se um botão for liberado
function keyReleased(){
  if(keyCode == RIGHT_ARROW){
    if(speedPX==6){
      speedPX=0;
    }
  } if (keyCode == LEFT_ARROW){
    if(speedPX==-6){
      speedPX=0;
    }
  }
}

function moverPlayer(){
  player.position(player.x+speedPX, player.y);
}

function moverItens() {
  for (i = 0; i < palavrasItem.length; i++) {
    if ((i + 1) % 2 == 1) {
      if ((i + 1) % 3 != 0) {
        quedas[i] = quedas[i] + speed1;
      } else {
        quedas[i] = quedas[i] + speed3;
      }
    } else {
      quedas[i] = quedas[i] + speed2;
    }
    palavrasItem[i].position(palavrasItem[i].x, quedas[i]);
  }
}

function checarLimites(){
  if(player.x+player.width+20 >= 600){
    isLimiteR = true;
    speedPX = 0;
  } else {
    isLimiteR = false;
  }

  if(player.x-4 <= 0){
    isLimiteL = true;
    speedPX = 0;
  } else{
    isLimiteL = false;
  }
}

function checarResetItem() {
  for (i = 0; i < palavrasItem.length; i++) {
    if (quedas[i]+palavrasItem[i].height+20 >= 400) {
      palavrasItem[i].remove();
      quedas[i] = 0;
      gerarPalavra(i);
    }
  }
}

function checarColisao(){
  for (i = 0; i < palavrasItem.length; i++) {
    pOrigenX = palavrasItem[i].x;
    pLargura = palavrasItem[i].x + palavrasItem[i].width;
    playerLargura = player.x + player.width;

    if((pOrigenX >= player.x && pOrigenX <= playerLargura) || (pLargura >= player.x && pLargura <= playerLargura) || (pLargura >= playerLargura && pOrigenX <= player.x)) {

      if (quedas[i] + palavrasItem[i].height + 20 >= player.y) {
        var isCorrect = false;
        var x;

        //testa se colidiu com palavra certas ou erradas
        for (x = 0; x < palavrasC.length; x++) {
          if (palavrasItem[i].html().toString() == palavrasC[x]) {
            isCorrect = true;
          }
        }

        if (isCorrect) {
          pontos = pontos + 10;
        } else {
          vidas--;
        }

        palavrasItem[i].remove();
        quedas[i] = 0;
        gerarPalavra(i);
      }
    }
  }
}

function embaralhar(array) {
  var indice_atual = array.length, valor_temporario, indice_aleatorio;

  while (0 !== indice_atual) {

    indice_aleatorio = Math.floor(Math.random() * indice_atual);
    indice_atual -= 1;

    valor_temporario = array[indice_atual];
    array[indice_atual] = array[indice_aleatorio];
    array[indice_aleatorio] = valor_temporario;
  }

  return array;
}

function criarBotaoVoltar(){
  bVoltar = createButton('⌂');
  bVoltar.position(10, 10);
  bVoltar.style("width", "40px");
  bVoltar.style("height", "40px");
  bVoltar.style("font-size", "32px");
  bVoltar.style("background-color", "#559");
  bVoltar.style("border-radius", "10px");
	
  //Função do button
  bVoltar.mousePressed(voltarHome);
}

function voltarHome(){
  if(isGameOver == false && cena == PLAY){
    limparTela();
    isGameOver = false;
  }else if(isGameOver==true){
    painel.remove();
    palavras = embaralhar(palavrasE.concat(palavrasC));
  }
  cena = MENU;
  bVoltar.remove();
  pontos = 0;
  vidas = 5;
}